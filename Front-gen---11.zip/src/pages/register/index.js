import React from "react";
import { Register } from "./../../components/login-register/Register";
const RegisterPage = () => {
  return <Register />;
};

export default RegisterPage;
